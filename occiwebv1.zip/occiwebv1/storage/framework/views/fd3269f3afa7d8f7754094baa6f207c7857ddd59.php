<?php $__env->startSection('page-content'); ?>


    <div class="utilisateurs container">
        <h1 class="title">NOUVEAU COMPTE</h1>
        <img src="<?php echo e(URL::to('/images/register.jpg')); ?>" alt="..."><br><br>

        <div class="form" style="padding-top: 25px">
            <form method="post" action="<?php echo e(route('utilisateurs.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="card border-dark " style="width: 18rem;">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <label>Username :</label><br>
                            <input type="text" name="username" required="required">
                        </li>
                        <li class="list-group-item">
                            <label>Mot de Passe :</label><br>
                            <input type="text" name="password" required="required">
                        </li>
                        <li class="list-group-item">
                            <label>Numero de telephone :</label><br>
                            <input type="number" name="numero" required="required">
                        </li>
                        <li class="list-group-item">
                            <label>Email :</label><br>
                            <input type="email" name="email" required="required">
                        </li>
                        <li class="list-group-item">
                            <button type="submit" class="btn btn-dark">S'enregister</button>
                        </li>
                    </ul>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\occiwebv1\resources\views/utilisateurs/create.blade.php ENDPATH**/ ?>