<?php $__env->startSection('page-content'); ?>


    <div class="recettes container">
        <h1 class="title">RECETTES</h1>
        <img src="<?php echo e(URL::to('/images/ustensiles.jpg')); ?>" alt="..."><br><br>
        
        <div class="contenu" style="padding-top: 25px">
            <?php $__currentLoopData = $recettes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recette): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3" style="max-width: 540px;">
                    <div class="row g-0">
                        <div class="col-md-4">
                            <img src="<?php echo e(URL::to('/images/'.$recette->image)); ?>" alt="...">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($recette->titre); ?></h5>
                                <a href="<?php echo e(route("recettes.show", $recette->id)); ?>" class="btn btn-warning">Details</a>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\occiwebv1\resources\views/recettes/index.blade.php ENDPATH**/ ?>