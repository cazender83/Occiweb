<nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="welcome.blade.php"><h2>OcciWeb</h2></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            
            <li class="nav-item active">
                <a class="nav-link" href="#">LA RADIO <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="#">ACTUALITÉ <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="#">LES PODCASTS <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="#">REPORTAGES <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(URL::route('gallery.index')); ?>">GALERIE <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(URL::route('recettes.create')); ?>">NOUVELLE RECETTE <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(URL::route('utilisateurs.create')); ?>">CREATION DE COMPTE <span class="sr-only">(current)</span></a>
            </li>
        </ul>

        <form class="d-flex" method="post" action="<?php echo e(URL::route('articles.searchR')); ?>">
            <?php echo e(method_field('GET')); ?>

            <?php echo csrf_field(); ?>
            <input class="form-control me-2" type="search" name="search" placeholder="Rechercher..." aria-label="search" style="margin-right:5%" >
            <button class="btn btn-dark" type="submit">RECHERCHER</button>
        </form>
    </div>
</nav>
<?php /**PATH C:\laragon\www\occiwebv1\resources\views/navbar.blade.php ENDPATH**/ ?>