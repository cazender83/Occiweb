<?php $__env->startSection('page-content'); ?>
    <div class="recettes">
        <h1>Detail de la recette</h1>
        <img src="<?php echo e(URL::to('/images/ustensiles.jpg')); ?>" alt="..."><br><br>

        <div class="progress" style="height: 1px;" >
            <div class="progress-bar w-100 bg-dark" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
        </div>

        <div class="form" style="padding-top: 25px">
            <a href="<?php echo e(route("recettes.edit", $recette->id)); ?>" class="btn btn-info">Edit</a>
            <h1><?php echo e($recette->titre); ?></h1>
            <video controls poster="images/<?php echo e($recette->image); ?>" width="900">
                <source src="video/<?php echo e($recette->video); ?>" type="video/mp4">
            </video>
            <div>
                <h3>Ingredients:</h3>
                <div style="padding-top: 25px">
                    <table class="table table-bordered table-striped table-dark">
                        <thead>
                        <tr>
                            <th>ingredient</th>
                            <th>nom</th>
                            <th>quantites</th>
                            <th>grammage</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $recette->ingredient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><img src="<?php echo e(URL::to('/images/ingredient/'.$ingredient->image)); ?>" height="60" width="60" ></td>
                            <td><?php echo e($ingredient->nom); ?></td>
                            <td><?php echo e($ingredient->pivot->quantite); ?></td>
                            <td><?php echo e($ingredient->desi_qt); ?></td>



                            <td class="d-flex justify-content-around">

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <h3>Progression de la recette :</h3>
            <p><?php echo e($recette->progression); ?></p>
            <h3>Remarques :</h3>
            <p><?php echo e($recette->remarque); ?></p>
            <h3>Etapes :</h3>
            <p><?php echo e($recette->etape); ?></p>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\occiwebv1\resources\views/recettes/show.blade.php ENDPATH**/ ?>