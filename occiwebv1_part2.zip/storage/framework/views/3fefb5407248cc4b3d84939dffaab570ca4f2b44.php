<?php $__env->startSection('page-content'); ?>


    <?php Session()->forget('users')?>
    <?php Session()->forget('type')?>

    <div class="form title utilisateurs container">
        <h1>Vous êtes maintenant déconnecté.</h1>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\occiwebv1\resources\views/utilisateurs/deconnect.blade.php ENDPATH**/ ?>