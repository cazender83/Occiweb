<?php $__env->startSection('page-content'); ?>


    <div class="container">
        <h1>Liste des ingredients</h1>
        <div class="progress" style="height: 1px;" >
            <div class="progress-bar w-100 bg-dark" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        <div style="padding-top: 25px">
            <table class="table table-bordered table-striped table-dark">
                <thead>
                <tr>
                    <th>image</th>
                    <th>nom</th>
                    <th>type de grammage</th>

                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($ingredient->nom); ?></td>
                        <td><?php echo e($ingredient->image); ?></td>
                        <td><?php echo e($ingredient->desi_qt); ?></td>
                        <td class="d-flex justify-content-around">
                            <a href="<?php echo e(route("ingredients.edit", $ingredient->id)); ?>" class="btn btn-warning">edit</a>
                            <a href="<?php echo e(route("ingredients.show", $ingredient->id)); ?>" class="btn btn-warning">Details</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\occiwebv1\resources\views/ingredients/index.blade.php ENDPATH**/ ?>