<?php $__env->startSection('page-content'); ?>


    <div class="gallerie" class="container">
        <h1 class="title">AJOUTER UNE IMAGE</h1>
        <div class="form">
            <form method="post" action="<?php echo e(route('gallery.store')); ?>">
                <?php echo csrf_field(); ?>
                <div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <label>Nom de l'image :</label><br>
                            <input type="text" name="image" required="required">
                        </li>
                        <li class="list-group-item">
                            <label>Description de l'image :</label><br>
                            <input type="text" name="alt" required="required">
                        </li>
                        <li class="list-group-item">
                            <label>Categorie :</label><br>
                            <select name="categorie" type="text">
                                <option value="animaux">Animaux</option>
                                <option value="architecture">Architecture</option>
                                <option value="divers">Divers</option>
                                <option value="fleurs">Fleurs</option>
                                <option value="mer">Mer</option>
                                <option value="nature">Nature</option>
                                <option value="motos">Motos</option>
                                <option value="voitures">Voitures</option>
                            </select>
                        </li>
                        <li class="list-group-item">
                            <button type="submit" class="btn btn-dark">Ajouter</button>
                        </li>
                    </ul>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\occiwebv1\resources\views/gallery/create.blade.php ENDPATH**/ ?>