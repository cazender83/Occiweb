<?php $__env->startSection('page-content'); ?>


    <div class="recettes" class="container">
        <h1 class="title">AJOUTER UNE RECETTE</h1>
        <img src="<?php echo e(URL::to('/images/ustensiles.jpg')); ?>" alt="..."><br><br>
        <div class="form">
            <form method="post" action="<?php echo e(route('recettes.store')); ?>">
                <?php echo csrf_field(); ?>
                <div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <label>Titre de la recette:</label><br>
                            <input type="text" name="titre" required="required">
                        </li>
                        <li class="list-group-item">
                            <label>Progression de la recette:</label><br>
                            <textarea name="progression" rows="5" cols="30" ></textarea>
                        </li>
                        <li class="list-group-item">
                            <label>Remarque:</label><br>
                            <textarea name="remarque" rows="5" cols="30" ></textarea>
                        </li>
                        <li class="list-group-item">
                            <label>Etapes:</label><br>
                            <textarea name="etape" rows="5" cols="30" ></textarea>
                        </li>
                        <li class="list-group-item">
                            <label>Video:</label><br>
                            <input type="text" name="video" required="required">
                        </li>
                        <li class="list-group-item">
                            <label>Image:</label><br>
                            <input type="text" name="image" required="required">
                        </li>
                        <li class="list-group-item">
                            <button type="submit" class="btn btn-dark">Ajouter</button>
                        </li>
                    </ul>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\occiwebv1\resources\views/recettes/create.blade.php ENDPATH**/ ?>