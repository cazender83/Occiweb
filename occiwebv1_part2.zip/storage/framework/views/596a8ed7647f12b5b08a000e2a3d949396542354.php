<?php $__env->startSection('page-content'); ?>


    <div class="container">
        <h1>Liste des utilisateurs</h1>
        <img src="<?php echo e(URL::to('/images/register.jpg')); ?>" alt="..."><br><br>

        <div class="progress" style="height: 1px;" >
            <div class="progress-bar w-100 bg-dark" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        <div style="padding-top: 25px">
            <table class="table table-bordered table-striped table-dark">
                <thead>
                <tr>
                    <th>Username</th>
                    <th>Mot de Passe</th>
                    <th>Email</th>
                    <th>Numero de telephone</th>
                    <th>Admin</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $utilisateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utilisateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($utilisateur->username); ?></td>
                        <td><?php echo e($utilisateur->password); ?></td>
                        <td><?php echo e($utilisateur->email); ?></td>
                        <td>+33 <?php echo e($utilisateur->numero); ?></td>
                        <?php if ($utilisateur->admin == 1) { ?>
                            <td>oui</td>
                        <?php } else { ?>
                            <td>non</td>
                        <?php } ?>
                        <td class="d-flex justify-content-around">
                            <a href="<?php echo e(route("utilisateurs.edit", $utilisateur->id)); ?>" class="btn btn-warning">edit</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\occiwebv1\resources\views/utilisateurs/index.blade.php ENDPATH**/ ?>