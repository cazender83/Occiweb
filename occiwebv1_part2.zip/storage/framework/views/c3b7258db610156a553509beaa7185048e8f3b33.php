<?php $__env->startSection('page-content'); ?>

    <div class="gallerie">
        <h1 class="title" style="font-size: 400%">Galerie d'Images</h1>
        <div class="container">
            <h1 class="title">Animaux <a href="<?php echo e(route("gallery.show", "animaux")); ?>" class="btn btn-warning">Voir la Galerie</a></h1>
            <div>
                <div id="carouselIndicatorsAnimal" class="carousel slide col w-100 p-0 mt-5" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php $__currentLoopData = $animauxFirst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animalFirst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item active">
                                <img src="<?php echo e(URL::to('/images/gallery/animaux/'.$animalFirst->image)); ?>" class="d-block w-100" alt="<?php echo e($animalFirst->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $animaux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item">
                                <img src="<?php echo e(URL::to('/images/gallery/animaux/'.$animal->image)); ?>" class="d-block w-100" alt="<?php echo e($animal->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="carousel-control-prev" href="#carouselIndicatorsAnimal" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselIndicatorsAnimal" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>

            </div>
        </div>

        <div class="container">
            <h1 class="title">Architecture <a href="<?php echo e(route("gallery.show", "architecture")); ?>" class="btn btn-warning">Voir la Galerie</a></h1>
            <div>
                <div id="carouselIndicatorsArchitecture" class="carousel slide col w-100 p-0 mt-5" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php $__currentLoopData = $architectureFirst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archiFirst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item active">
                                <img src="<?php echo e(URL::to('/images/gallery/architecture/'.$archiFirst->image)); ?>" class="d-block w-100" alt="<?php echo e($archiFirst->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $architecture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item">
                                <img src="<?php echo e(URL::to('/images/gallery/architecture/'.$archi->image)); ?>" class="d-block w-100" alt="<?php echo e($archi->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="carousel-control-prev" href="#carouselIndicatorsArchitecture" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselIndicatorsArchitecture" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>

            </div>
        </div>

        <div class="container">
            <h1 class="title">Divers <a href="<?php echo e(route("gallery.show", "divers")); ?>" class="btn btn-warning">Voir la Galerie</a></h1>
            <div>
                <div id="carouselIndicatorsDivers" class="carousel slide col w-100 p-0 mt-5" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php $__currentLoopData = $diversFirst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diverFirst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item active">
                                <img src="<?php echo e(URL::to('/images/gallery/divers/'.$diverFirst->image)); ?>" class="d-block w-100" alt="<?php echo e($diverFirst->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $divers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item">
                                <img src="<?php echo e(URL::to('/images/gallery/divers/'.$diver->image)); ?>" class="d-block w-100" alt="<?php echo e($diver->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="carousel-control-prev" href="#carouselIndicatorsDivers" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselIndicatorsDivers" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>

            </div>
        </div>

        <div class="container">
            <h1 class="title">Fleurs <a href="<?php echo e(route("gallery.show", "fleurs")); ?>" class="btn btn-warning">Voir la Galerie</a></h1>
            <div>
                <div id="carouselIndicatorsFleurs" class="carousel slide col w-100 p-0 mt-5" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php $__currentLoopData = $fleursFirst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fleurFirst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item active">
                                <img src="<?php echo e(URL::to('/images/gallery/fleurs/'.$fleurFirst->image)); ?>" class="d-block w-100" alt="<?php echo e($fleurFirst->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $fleurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fleur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item">
                                <img src="<?php echo e(URL::to('/images/gallery/fleurs/'.$fleur->image)); ?>" class="d-block w-100" alt="<?php echo e($fleur->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="carousel-control-prev" href="#carouselIndicatorsFleurs" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselIndicatorsFleurs" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>

            </div>
        </div>

        <div class="container">
            <h1 class="title">Mer <a href="<?php echo e(route("gallery.show", "mer")); ?>" class="btn btn-warning">Voir la Galerie</a></h1>
            <div>
                <div id="carouselIndicatorsMer" class="carousel slide col w-100 p-0 mt-5" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php $__currentLoopData = $merFirst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meFirst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item active">
                                <img src="<?php echo e(URL::to('/images/gallery/mer/'.$meFirst->image)); ?>" class="d-block w-100" alt="<?php echo e($meFirst->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $mer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $me): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item">
                                <img src="<?php echo e(URL::to('/images/gallery/mer/'.$me->image)); ?>" class="d-block w-100" alt="<?php echo e($me->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="carousel-control-prev" href="#carouselIndicatorsMer" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselIndicatorsMer" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>

            </div>
        </div>

        <div class="container">
            <h1 class="title">Nature <a href="<?php echo e(route("gallery.show", "nature")); ?>" class="btn btn-warning">Voir la Galerie</a></h1>
            <div>
                <div id="carouselIndicatorsNature" class="carousel slide col w-100 p-0 mt-5" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php $__currentLoopData = $natureFirst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $natuFirst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item active">
                                <img src="<?php echo e(URL::to('/images/gallery/nature/'.$natuFirst->image)); ?>" class="d-block w-100" alt="<?php echo e($natuFirst->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $nature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $natu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item">
                                <img src="<?php echo e(URL::to('/images/gallery/nature/'.$natu->image)); ?>" class="d-block w-100" alt="<?php echo e($natu->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="carousel-control-prev" href="#carouselIndicatorsNature" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselIndicatorsNature" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>

            </div>
        </div>

        <div class="container">
            <h1 class="title">Motos <a href="<?php echo e(route("gallery.show", "motos")); ?>" class="btn btn-warning">Voir la Galerie</a></h1>
            <div>
                <div id="carouselIndicatorsMotos" class="carousel slide col w-100 p-0 mt-5" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php $__currentLoopData = $motosFirst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motoFirst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item active">
                                <img src="<?php echo e(URL::to('/images/gallery/motos/'.$motoFirst->image)); ?>" class="d-block w-100" alt="<?php echo e($motoFirst->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $motos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item">
                                <img src="<?php echo e(URL::to('/images/gallery/motos/'.$moto->image)); ?>" class="d-block w-100" alt="<?php echo e($moto->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="carousel-control-prev" href="#carouselIndicatorsMotos" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselIndicatorsMotos" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>

            </div>
        </div>

        <div class="container">
            <h1 class="title">Voitures <a href="<?php echo e(route("gallery.show", "voiture")); ?>" class="btn btn-warning">Voir la Galerie</a></h1>
            <div>
                <div id="carouselIndicatorsVoiture" class="carousel slide col w-100 p-0 mt-5" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php $__currentLoopData = $voituresFirst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voitureFirst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item active">
                                <img src="<?php echo e(URL::to('/images/gallery/voitures/'.$voitureFirst->image)); ?>" class="d-block w-100" alt="<?php echo e($voitureFirst->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $voitures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voiture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item">
                                <img src="<?php echo e(URL::to('/images/gallery/voitures/'.$voiture->image)); ?>" class="d-block w-100" alt="<?php echo e($voiture->alt); ?>">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="carousel-control-prev" href="#carouselIndicatorsVoiture" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselIndicatorsVoiture" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>

            </div>
        </div>
        <br><br>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\occiwebv1\resources\views/gallery/index.blade.php ENDPATH**/ ?>