<?php $__env->startSection('page-content'); ?>

        <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accounts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php session(['users' => $accounts->id])?>
            <?php session(['type' => $accounts->type])?>

            <div class="form title utilisateurs container">
                <h1>Bienvenue <?php echo e($accounts->username); ?> </h1>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\occiwebv1\resources\views/utilisateurs/connected.blade.php ENDPATH**/ ?>