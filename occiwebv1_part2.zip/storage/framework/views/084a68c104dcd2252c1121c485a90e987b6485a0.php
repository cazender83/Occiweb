<?php $__env->startSection('page-content'); ?>
    <?php $__currentLoopData = $recettes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recette): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="ingredients" class="container">
        <h1>ingredients de <?php echo e($recette->titre); ?></h1>
        <div style="padding-top: 25px">

            <form method="post" action="<?php echo e(route('ingredients.addInRecette', $recette->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <input type="checkbox" id="<?php echo e($ingredient->nom); ?>" name="ingredient[]" value="<?php echo e($ingredient->id); ?>">
                        <img src="<?php echo e(URL::to('/images/ingredient/'.$ingredient->image)); ?>" height="60" width="60" >
                        <label for="<?php echo e($ingredient->nom); ?>"><?php echo e($ingredient->nom); ?></label>
                        <br>
                        <label>Quantiter en <?php echo e($ingredient->desi_qt); ?>:</label><br>
                        <input type="number" name="<?php echo e($ingredient->id); ?>">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <button type="submit">Ajouter</button>
                </div>
            </form>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\occiwebv1\resources\views/ingredients/addIngredients.blade.php ENDPATH**/ ?>