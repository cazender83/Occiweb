<?php $__env->startSection('page-content'); ?>


    <div class="utilisateurs container">
        <h1 class="title">CONNEXION </h1>
        <div class="form" style="padding-top: 25px; color: white">
            <form class="my-2 my-lg-0" method="post" action="<?php echo e(URL::route('utilisateurs.connection')); ?>">
                <?php echo e(method_field('GET')); ?>

                <?php echo csrf_field(); ?>
                <label>Nom d'utilisateur : </label>
                <input class="form-control mr-sm-2" name="username" type="text" placeholder="Nom d'utilisateur..."
                       aria-label="username"><hr>
                <label>Mot de Passe : </label>
                <input class="form-control mr-sm-2" name="password" type="password" placeholder="Mot de passe..."
                       aria-label="password"><br>
                <button class="btn btn-dark my-2 my-sm-0" type="submit">Connexion</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\occiwebv1\resources\views/utilisateurs/connexion.blade.php ENDPATH**/ ?>