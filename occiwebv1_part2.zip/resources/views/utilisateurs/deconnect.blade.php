@extends('footer')
@extends('layout')

@section('page-content')


    <?php Session()->forget('users')?>
    <?php Session()->forget('type')?>

    <div class="form title utilisateurs container">
        <h1>Vous êtes maintenant déconnecté.</h1>
    </div>

@endsection
