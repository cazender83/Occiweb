@extends('footer')
@extends('layout')

@section('page-content')


    <div class="utilisateurs container">
        <h1 class="title">CONNEXION </h1>
        <div class="form" style="padding-top: 25px; color: white">
            <form class="my-2 my-lg-0" method="post" action="{{ URL::route('utilisateurs.connection') }}">
                {{ method_field('GET') }}
                @csrf
                <label>Nom d'utilisateur : </label>
                <input class="form-control mr-sm-2" name="username" type="text" placeholder="Nom d'utilisateur..."
                       aria-label="username"><hr>
                <label>Mot de Passe : </label>
                <input class="form-control mr-sm-2" name="password" type="password" placeholder="Mot de passe..."
                       aria-label="password"><br>
                <button class="btn btn-dark my-2 my-sm-0" type="submit">Connexion</button>
            </form>
        </div>
    </div>

@endsection
