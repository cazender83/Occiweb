@extends('footer')
@extends('layout')

@section('page-content')


    <div class="recettes container">
        <h1 class="title">RECETTES</h1>
        <img src="{{ URL::to('/images/ustensiles.jpg') }}" alt="..."><br><br>
        <a href="{{ route("recettes.create") }}" class="btn btn-warning">Ajouter une recette</a>
        
        <div class="contenu" style="padding-top: 25px">
            @foreach($recettes as $recette)
                <div class="card mb-3" style="max-width: 540px;">
                    <div class="row g-0">
                        <div class="col-md-4">
                            <img src="{{ URL::to('/images/'.$recette->image) }}" alt="...">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title">{{ $recette->titre }}</h5>
                                <a href="{{ route("recettes.show", $recette->id) }}" class="btn btn-warning">Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach

        </div>
    </div>

@endsection
